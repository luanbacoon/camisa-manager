/**
 * Testes abrangentes dos routers tRPC
 * Cobre autenticação, autorização, validação de inputs e lógica de negócio.
 */
import { describe, it, expect } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// ─── Helpers ──────────────────────────────────────────────────────────────────

function createAuthContext(role: "admin" | "user" = "admin"): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "test-owner",
      email: "owner@example.com",
      name: "Owner",
      loginMethod: "email",
      role,
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };
}

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: { protocol: "https", headers: {} } as TrpcContext["req"],
    res: { clearCookie: () => {} } as TrpcContext["res"],
  };
}

// ─── Auth ─────────────────────────────────────────────────────────────────────

describe("auth.me", () => {
  it("retorna o usuário autenticado", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    const result = await caller.auth.me();
    expect(result).not.toBeNull();
    expect(result?.name).toBe("Owner");
    expect(result?.role).toBe("admin");
  });

  it("retorna null quando não autenticado", async () => {
    const caller = appRouter.createCaller(createPublicContext());
    const result = await caller.auth.me();
    expect(result).toBeNull();
  });
});

describe("auth.logout", () => {
  it("retorna sucesso e limpa o cookie", async () => {
    const cleared: string[] = [];
    const ctx: TrpcContext = {
      ...createAuthContext(),
      res: { clearCookie: (name: string) => cleared.push(name) } as TrpcContext["res"],
    };
    const result = await appRouter.createCaller(ctx).auth.logout();
    expect(result).toEqual({ success: true });
    expect(cleared).toHaveLength(1);
  });
});

// ─── Proteção de rotas ────────────────────────────────────────────────────────

describe("proteção de rotas — UNAUTHORIZED sem autenticação", () => {
  const publicCaller = () => appRouter.createCaller(createPublicContext());

  it("products.list", async () => {
    await expect(publicCaller().products.list()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
  it("customers.list", async () => {
    await expect(publicCaller().customers.list()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
  it("sales.list", async () => {
    await expect(publicCaller().sales.list()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
  it("stock.list", async () => {
    await expect(publicCaller().stock.list()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
  it("supplierOrders.list", async () => {
    await expect(publicCaller().supplierOrders.list()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
  it("settings.get", async () => {
    await expect(publicCaller().settings.get()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
  it("catalog.orders", async () => {
    await expect(publicCaller().catalog.orders()).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
});

// ─── Endpoints públicos ───────────────────────────────────────────────────────

describe("endpoints públicos (sem autenticação)", () => {
  it("catalog.products retorna array", async () => {
    const result = await appRouter.createCaller(createPublicContext()).catalog.products({});
    expect(Array.isArray(result)).toBe(true);
  });

  it("catalog.settings retorna objeto ou null", async () => {
    const result = await appRouter.createCaller(createPublicContext()).catalog.settings();
    expect(result === null || typeof result === "object").toBe(true);
  });
});

// ─── Listagens autenticadas ───────────────────────────────────────────────────

describe("listagens autenticadas retornam arrays", () => {
  let caller: ReturnType<typeof appRouter.createCaller>;
  caller = appRouter.createCaller(createAuthContext());

  it("products.list", async () => expect(Array.isArray(await caller.products.list())).toBe(true));
  it("customers.list", async () => expect(Array.isArray(await caller.customers.list())).toBe(true));
  it("sales.list", async () => expect(Array.isArray(await caller.sales.list())).toBe(true));
  it("stock.list", async () => expect(Array.isArray(await caller.stock.list())).toBe(true));
  it("supplierOrders.list", async () => expect(Array.isArray(await caller.supplierOrders.list())).toBe(true));
  it("catalog.orders", async () => expect(Array.isArray(await caller.catalog.orders())).toBe(true));
  it("stock.history", async () => expect(Array.isArray(await caller.stock.history())).toBe(true));
});

// ─── Validação de inputs ──────────────────────────────────────────────────────

describe("validação de inputs", () => {
  const caller = () => appRouter.createCaller(createAuthContext());
  const publicCaller = () => appRouter.createCaller(createPublicContext());

  it("stock.adjust rejeita justificativa curta (< 5 chars)", async () => {
    await expect(
      caller().stock.adjust({ productId: 1, size: "M", newQuantity: 10, reason: "ok" })
    ).rejects.toThrow();
  });

  it("sales.create rejeita forma de pagamento inválida", async () => {
    await expect(
      (caller().sales.create as any)({
        customerId: 1,
        paymentMethod: "boleto",
        items: [{ productId: 1, size: "M", quantity: 1, unitPrice: 100, unitCost: 50 }],
      })
    ).rejects.toThrow();
  });

  it("sales.create rejeita itens com quantidade 0", async () => {
    await expect(
      caller().sales.create({
        customerId: 1,
        paymentMethod: "pix",
        items: [{ productId: 1, size: "M", quantity: 0, unitPrice: 100, unitCost: 50 }],
      })
    ).rejects.toThrow();
  });

  it("sales.create rejeita desconto negativo", async () => {
    await expect(
      caller().sales.create({
        customerId: 1,
        paymentMethod: "pix",
        discountValue: -10,
        items: [{ productId: 1, size: "M", quantity: 1, unitPrice: 100, unitCost: 60 }],
      })
    ).rejects.toThrow();
  });

  it("products.create rejeita nome vazio", async () => {
    await expect(
      caller().products.create({ name: "", cost: 50, price: 100, sizes: [{ size: "M", stock: 5 }] })
    ).rejects.toThrow();
  });

  it("customers.create rejeita nome vazio", async () => {
    await expect(caller().customers.create({ name: "" })).rejects.toThrow();
  });

  it("catalog.submitOrder rejeita pedido sem customerPhone", async () => {
    await expect(
      (publicCaller().catalog.submitOrder as any)({
        customerName: "João",
        items: [{ productId: 1, productName: "Camisa", size: "M", quantity: 1, unitPrice: 100 }],
      })
    ).rejects.toThrow();
  });

  it("supplierOrders.create rejeita quantidade 0", async () => {
    await expect(
      caller().supplierOrders.create({ productId: 1, size: "M", quantity: 0, unitCost: 50 })
    ).rejects.toThrow();
  });
});

// ─── Lógica de negócio ────────────────────────────────────────────────────────

describe("simulator.calculate", () => {
  it("lança erro para produto inexistente no banco", async () => {
    const caller = appRouter.createCaller(createAuthContext());
    await expect(
      caller.simulator.calculate({ productId: 999999, newQuantity: 10, newUnitCost: 50 })
    ).rejects.toThrow();
  });
});

describe("settings", () => {
  it("settings.get retorna objeto ou null quando autenticado", async () => {
    const result = await appRouter.createCaller(createAuthContext()).settings.get();
    expect(result === null || typeof result === "object").toBe(true);
  });
});

describe("role: usuário comum acessa rotas protectedProcedure", () => {
  it("products.list acessível para role=user", async () => {
    const result = await appRouter.createCaller(createAuthContext("user")).products.list();
    expect(Array.isArray(result)).toBe(true);
  });
});
