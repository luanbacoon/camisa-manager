-- Migração: normalizar itens de pedidos do catálogo
-- Cria tabela catalog_order_items e migra dados do JSON para linhas relacionais

CREATE TABLE IF NOT EXISTS `catalog_order_items` (
  `id` int AUTO_INCREMENT PRIMARY KEY,
  `orderId` int NOT NULL,
  `productId` int,
  `productName` varchar(255) NOT NULL,
  `size` varchar(20) NOT NULL,
  `quantity` int NOT NULL DEFAULT 1,
  `unitPrice` decimal(10,2) NOT NULL DEFAULT '0.00',
  `createdAt` timestamp NOT NULL DEFAULT (now()),
  INDEX `catalog_order_items_orderId_idx` (`orderId`)
);

-- Migrar dados existentes do campo JSON para a nova tabela
-- Este bloco deve ser executado após criar a tabela
-- e antes de remover a coluna items da tabela catalog_orders

-- NOTA: A coluna `items` em catalog_orders é mantida temporariamente
-- para compatibilidade retroativa. Após confirmar que todos os dados
-- foram migrados, execute:
-- ALTER TABLE `catalog_orders` DROP COLUMN `items`;
